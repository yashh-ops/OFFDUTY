import { Link } from "react-router-dom";
import heroImage from "../../assets/hero/unboxstorehero1.png";
export default function Hero() {
  return (
    <section className="relative min-h-[76svh] overflow-hidden bg-[#20221e] text-white sm:min-h-[85vh]">
      <img
        src={heroImage}
        alt="OFFDUTY original campaign artwork"
        className="absolute inset-0 h-full w-full object-cover opacity-70"
      />
      <div className="absolute inset-0 bg-gradient-to-r from-black/75 via-black/30 to-transparent" />
      <div className="relative mx-auto flex min-h-[76svh] max-w-[1500px] flex-col justify-end px-5 pb-20 sm:min-h-[85vh] sm:px-12">
        <p className="mb-4 text-xs font-bold uppercase tracking-[.35em]">
          OFFDUTY / DROP 001
        </p>
        <h1 className="max-w-full break-words text-[clamp(3.7rem,12vw,11rem)] font-black leading-[.9] tracking-[-.075em]">
          OFFDUTY.
        </h1>
        <p className="mt-6 text-sm font-semibold uppercase tracking-[.22em]">
          Made for your own lane.
        </p>
        <p className="mt-3 max-w-lg text-sm text-white/80">
          Oversized fits. Everyday essentials. No dress code, no compromise.
        </p>
        <div className="mt-8 flex flex-wrap gap-3">
          <Link
            className="bg-white px-6 py-4 text-xs font-bold uppercase tracking-widest text-black hover:bg-[#d4d0c7]"
            to="/shop?gender=men"
          >
            Shop Men ↗
          </Link>
          <Link
            className="border border-white px-6 py-4 text-xs font-bold uppercase tracking-widest text-white hover:bg-white hover:text-black"
            to="/shop?gender=women"
          >
            Shop Women ↗
          </Link>
        </div>
      </div>
    </section>
  );
}
